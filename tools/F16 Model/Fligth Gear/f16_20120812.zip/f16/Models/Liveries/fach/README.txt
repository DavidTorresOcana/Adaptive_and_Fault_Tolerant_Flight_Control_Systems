FACH (CHILE AIR FORCE) LIVERY FOR F16
-------------------------------------


This livery was created only for use in the Open Source flight simulator "FlightGear".


HOW TO INSTALL
--------------
Unzip "fach.xml" file and "fach" folder in the Aircraft/f16/Models/Liveries/ directory.


(The original model have an extra file for numbers and ensigns. In this file are no independient signs; then, the file was replaced with a transparent image).



By Pavel "El Flauta" Cueto - 2009
GPL licence